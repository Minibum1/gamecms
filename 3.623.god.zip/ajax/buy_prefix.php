<?php

if(isset($gifts)) {
	$data = '<input type="text" class="form-control mt-10" maxlength="32" id="player_steam_id" placeholder="Введите свой STEAM ID">
	<input type="text" class="form-control mt-10" maxlength="32" id="player_efield" placeholder="Введите желаемый префикс">';
	return array('status' => '1', 'data' => $data, 'text' => '');
} else {
	$player_prefix = checkJs($_POST['player_efield'], null);
	
	if(empty($player_prefix)) {
		exit (json_encode(array('status' => '2', 'input' => 'player_efield', 'reply' => 'Заполните!')));
	}
	if(mb_strlen($player_prefix, 'UTF-8') > 32) {
		exit (json_encode(array('status' => '2', 'input' => 'player_efield', 'reply' => 'Не более 32 символов!')));
	}
	
	$STH = $pdo->query("SELECT id,pirce,time,discount FROM gifts__tarifs WHERE id='$tarif' and service='$service->id' LIMIT 1");
	$STH->setFetchMode(PDO::FETCH_OBJ);
	$tarif = $STH->fetch();
	if(empty($tarif->id)) {
		exit (json_encode(array('status' => '3', 'data' => 'Тариф не найден')));
	}

	if(!$pdo2 = db_connect($service->dbhost, $service->dbname, $service->dbuser, $service->dbpass)) {
		exit (json_encode(array('status' => '3', 'data' => 'Не удалось подключиться к удаленному серверу')));
		return false;
	}

	set_names($pdo2, $server->db_code);
	
	$STH = $pdo->query("SELECT discount FROM config__prices LIMIT 1");
	$STH->setFetchMode(PDO::FETCH_OBJ);
	$row = $STH->fetch();

	$proc = calculate_discount($server->discount, $row->discount, $user->proc, $service->discount, $tarif->discount);
	$pirce = calculate_pirce($tarif->pirce, $proc);

	$STH = $pdo->query("SELECT id,shilings FROM users WHERE id='$_SESSION[id]' LIMIT 1");
	$STH->setFetchMode(PDO::FETCH_OBJ);
	$row = $STH->fetch();
	if(empty($row->id)) {
		exit (json_encode(array('status' => '3', 'data' => 'Пользователь не найден')));
	}
	if($row->shilings < $pirce) {
		$pirce_delta = round_shilings($pirce - $row->shilings);
		exit (json_encode(array('status' => '3',
								'data'   => 'У Вас недостаточно средств <span class="m-icon icon-bank"></span><br><a href="../purse?pirce='.$pirce_delta.'">Пополните баланс на '.$pirce_delta.$messages['RUB'].'.</a>')));
	}
	$shilings = round_shilings($row->shilings - $pirce);
	
	$STH = $pdo2->prepare("SELECT * FROM `gift_module` WHERE `etype` = 'prefix' AND `authid`=:steamid LIMIT 1"); $STH->setFetchMode(PDO::FETCH_OBJ);
	$STH->execute(array( ':steamid' => $steam_id ));
	$prefix = $STH->fetch();
	
	if( !empty( $prefix->id ) )
	{
		exit (json_encode(array('status' => '3', 'data' => 'У данного пользователя имеется префикс')));
	}
	
	$STH = $pdo2->prepare("INSERT INTO `gift_module`(`authid`,`efield`,`expire_date`,`etype`,`user_id`,`estate`) VALUES (:steamid,:prefix,FROM_UNIXTIME(:offtime),'prefix',:user_id,2)");
	if ($STH->execute(array( ':steamid' => $steam_id, ':prefix' => $player_prefix, ':user_id' => $_SESSION['id'], ':offtime' => ( time() + ( $tarif->time * 86400 ) ) )) != '1') {
		exit (json_encode(array('status' => '3', 'data' => 'Не удалось выдать префикс, повторите попытку ещё раз')));
		return false;
	}

	service_log('Покупка префикса: '.$player_prefix.' '.$tarif->time.' дней', $_SESSION['id'], $server->id, $pdo);
	
	$STH = $pdo->prepare("UPDATE users SET shilings=:shilings WHERE id=:id LIMIT 1");
	$STH->execute(array(':shilings' => $shilings, ':id' => $_SESSION['id']));

	$STH = $pdo->prepare("INSERT INTO money__actions (date,shilings,author,type) VALUES (:date, :shilings, :author, :type)");
	$STH->execute(array('date' => date("Y-m-d H:i:s"), 'shilings' => -$pirce, 'author' => $_SESSION['id'], 'type' => '2'));

	include_once "../inc/notifications.php";

	$full_mess = 'Приобретение префикса';
	$full_mess .= '<br>Префикс: '.$player_prefix;
	$full_mess .= '<br>STEAM ID: '.$steam_id;

	send_noty($pdo, $full_mess, $_SESSION['id'], 2);

	$noty = 'Пользователь '.$_SESSION['login'].'['.$_SESSION['id'].']<br>'.$full_mess;
	send_noty($pdo, $noty, 0, 2);
	
	exit (json_encode(array('status' => '1', 'data' => '<h4>Услуга успешно приобретена!</h4>', 'shilings' => $shilings)));
}