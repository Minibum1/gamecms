<?php
require "{$_SERVER['DOCUMENT_ROOT']}/inc/classes/class.database.php";
$injSql = new Database($db);
unset($db);

$STH = $pdo->query("SELECT * FROM config LIMIT 1"); $STH->setFetchMode(PDO::FETCH_OBJ);
$conf = $STH->fetch();

?>